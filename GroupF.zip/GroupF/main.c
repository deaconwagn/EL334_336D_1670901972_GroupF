/*
 * ============================================================================
 *  EL334 Mini-Project : Smart Traffic Light
 * ============================================================================
 *  Board    : NXP FRDM-K64F (MCU = MK64FN1M0VLL12, ARM Cortex-M4)
 *  Shield   : Multi-functional Shield (designed for Arduino UNO, plugged into
 *             the Arduino-compatible headers of the FRDM-K64F)
 *  Language : C, bare-metal register access via the CMSIS device header
 *             <MK64F12.h> (no SDK drivers, no RTOS)
 *
 *  ----------------------------------------------------------------------------
 *  WHAT THE PROGRAM DOES
 *  ----------------------------------------------------------------------------
 *  Function 1 : Normal traffic light
 *               The car signal cycles GREEN -> YELLOW -> RED -> GREEN ...
 *               The 7-segment display shows the current state letter and the
 *               number of seconds left before the light changes.
 *
 *  Function 2 : Pedestrian button (S1)
 *               - Pressed during GREEN  : the remaining green time is cut down
 *                 to T_PED_SHORTEN seconds, then the light goes yellow -> red
 *                 and pedestrians may cross during that red phase.
 *               - Pressed during YELLOW : the request is kept and served on the
 *                 next red phase.
 *               - Pressed during RED    : cars are already stopped, so the WALK
 *                 light turns on (almost) immediately. If too little red time
 *                 is left, it is extended to T_WALK_MIN seconds.
 *               While pedestrians cross, LED D4 (WALK) is on and the buzzer
 *               ticks once per second (audible signal, like real crossings).
 *
 *  Function 3 : Police emergency button (S2)
 *               - 1st press : enter police-control mode. Every car must stop:
 *                 red light ON, yellow light blinking, WALK light OFF,
 *                 7-segment shows "StoP", buzzer gives a short tick per second.
 *               - 2nd press : leave police-control mode. The normal cycle is
 *                 restarted from RED (safe restart: cars never jump straight
 *                 to green).
 *
 *  ----------------------------------------------------------------------------
 *  HARDWARE / PERIPHERALS USED (mapped to the grading table)
 *  ----------------------------------------------------------------------------
 *  - Switch    : S1 (PTB3)  -> pedestrian request
 *                S2 (PTB10) -> police emergency
 *  - LED       : D1 = Red, D2 = Yellow, D3 = Green (car signal)
 *                D4 = WALK (pedestrian signal)
 *  - 7-Segment : 4-digit common-anode display driven by two 74HC595 shift
 *                registers (state letter + countdown / "StoP")
 *  - Timer     : PIT channel 0 -> 1 s time base for the traffic light
 *                PIT channel 1 -> 2 ms time base for display multiplexing,
 *                                 buzzer beep length and button debounce
 *                FTM0 channel 6 -> 4 kHz PWM used to control buzzer loudness
 *  - Interrupt : PORTB pin interrupt (S1, S2 on falling edge)
 *                PIT0 interrupt, PIT1 interrupt
 *  - Extra     : Piezo buzzer with software-adjustable volume
 *
 *  ----------------------------------------------------------------------------
 *  PROGRAM STRUCTURE (foreground / background design)
 *  ----------------------------------------------------------------------------
 *  - Interrupt Service Routines (ISRs) are kept very short. They only set
 *    flags or counters (pedRequest, emergencyReq, secondFlag, tick2ms) and
 *    do time-critical jobs (display refresh, switching the buzzer off).
 *  - The main loop (background) reads these flags and calls the three
 *    function blocks. All decisions about changing lights happen there.
 *    This avoids long code inside ISRs and keeps the system responsive.
 * ============================================================================
 */

#include <MK64F12.h>   /* CMSIS device header: register structs (SIM, PORTx,
                          PTx, PIT, FTM0, NVIC ...) and bit-field macros     */
#include <stdint.h>    /* fixed-width integer types: uint8_t, uint16_t ...   */

/* MASK(x) creates a 32-bit value with only bit x set to 1.
 * Example: MASK(3) = 0x00000008. Used to select one pin inside a 32-pin port.
 * "1UL" makes the constant unsigned long so shifting up to bit 31 is safe.   */
#define MASK(x) (1UL << (x))

/* ============================================================================
 *  PIN MAP
 *  Path of each signal: Shield part -> Arduino header pin -> K64F port pin.
 *  The number in each #define is the PIN NUMBER inside its port
 *  (e.g. LED_RED = 1 means bit 1 of Port D = PTD1).
 * ==========================================================================*/
#define LED_RED      1    /* D1  <- Arduino D13 -> PTD1                       */
#define LED_YELLOW   3    /* D2  <- Arduino D12 -> PTD3                       */
#define LED_GREEN    2    /* D3  <- Arduino D11 -> PTD2                       */
#define LED_WALK     0    /* D4  <- Arduino D10 -> PTD0                       */
#define SW1          3    /* S1  <- Arduino A1  -> PTB3  : pedestrian button  */
#define SW2          10   /* S2  <- Arduino A2  -> PTB10 : emergency button   */
#define BUZZER       1    /* LS1 <- Arduino D3  -> PTA1
                             The buzzer is switched by PNP transistor Q1
                             through R9 (10k): pin LOW = transistor ON =
                             buzzer sounds; pin HIGH = buzzer off.            */
#define SEG_LATCH    23   /* 74HC595 LCHCLK (storage/latch clock) <- D4 -> PTB23 */
#define SEG_CLK      3    /* 74HC595 SFTCLK (shift clock)         <- D7 -> PTC3  */
#define SEG_DATA     12   /* 74HC595 SDI    (serial data in)      <- D8 -> PTC12 */

/* ============================================================================
 *  TIMING CONSTANTS
 * ==========================================================================*/
#define T_GREEN        15     /* green time for cars (seconds)                */
#define T_YELLOW       3      /* yellow time for cars (seconds)               */
#define T_RED          10     /* red time for cars = crossing time (seconds)  */
#define T_PED_SHORTEN  3      /* when S1 is pressed during green, the green
                                 time left is reduced to this (seconds)       */
#define T_WALK_MIN     6      /* when S1 is pressed during red, pedestrians
                                 get at least this many seconds to cross      */
#define DEBOUNCE_TICKS 100    /* button debounce window, counted in PIT1 ticks:
                                 100 ticks x 2 ms = 200 ms. Extra edges
                                 caused by contact bounce inside this window
                                 are ignored.                                 */

/* ============================================================================
 *  BUZZER SOUND SETTINGS
 *  Loudness is set by the PWM duty cycle (percentage of each PWM period in
 *  which the buzzer is driven). Lower % = quieter.
 * ==========================================================================*/
#define BUZZ_VOLUME    5      /* normal loudness, 0-100 %  (adjust here)      */
#define BUZZ_VOL_EMG   3      /* emergency-mode loudness, 0-100 % (adjust)    */
#define BUZZ_PWM_FREQ  4000   /* PWM frequency in Hz                          */
#define BEEP_WALK      30     /* beep length (ms) every second while crossing */
#define BEEP_EMG_ENTER 80     /* beep length (ms) when police take control    */
#define BEEP_EMG_EXIT  40     /* beep length (ms) when returning to normal    */
#define BEEP_EMG_TICK  10     /* beep length (ms) every second in emergency   */

/* ============================================================================
 *  7-SEGMENT CODES
 *  The display is COMMON ANODE, so a segment lights when its cathode line is
 *  driven LOW -> segment bit = 0 means ON, 1 means OFF (active LOW).
 *
 *  Bit order of one segment byte:
 *      bit:   7   6   5   4   3   2   1   0
 *      seg:  dp   g   f   e   d   c   b   a
 *
 *           a
 *         -----
 *      f |     | b
 *        |  g  |
 *         -----
 *      e |     | c
 *        |     |
 *         -----  . dp
 *           d
 *
 *  Example: '0' needs a,b,c,d,e,f ON and g,dp OFF
 *           -> bits 7..0 = 1 1 0 0 0 0 0 0 = 0xC0
 * ==========================================================================*/
static const uint8_t SEG_NUM[10] = {
    0xC0,   /* 0 */
    0xF9,   /* 1 */
    0xA4,   /* 2 */
    0xB0,   /* 3 */
    0x99,   /* 4 */
    0x92,   /* 5 */
    0x82,   /* 6 */
    0xF8,   /* 7 */
    0x80,   /* 8 */
    0x90    /* 9 */
};
#define SEG_r      0xAF   /* 'r' : segments e, g          -> RED state         */
#define SEG_Y      0x91   /* 'Y' : segments b, c, d, f, g -> YELLOW state      */
#define SEG_G      0xC2   /* 'G' : segments a, c, d, e, f -> GREEN state       */
#define SEG_P      0x8C   /* 'P' : segments a, b, e, f, g -> pedestrian / StoP */
#define SEG_S      0x92   /* 'S' : same pattern as digit 5                     */
#define SEG_t      0x87   /* 't' : segments d, e, f, g                         */
#define SEG_o      0xA3   /* 'o' : segments c, d, e, g                         */
#define SEG_BLANK  0xFF   /* all segments OFF                                  */

/* Digit-select byte sent to the second 74HC595. Its outputs QA..QD drive the
 * common anode of digit 1..4. A HIGH bit powers that digit. Only one bit is
 * HIGH at a time, so only one digit is lit at any moment (multiplexing).
 * The upper nibble (0xF_) is not connected to a digit.                       */
static const uint8_t DIGIT_SEL[4] = {
    0xF1,   /* digit 1 (leftmost)  */
    0xF2,   /* digit 2             */
    0xF4,   /* digit 3             */
    0xF8    /* digit 4 (rightmost) */
};

/* ============================================================================
 *  GLOBAL STATE
 * ==========================================================================*/

/* The three states of the car traffic light.
 * The enum value is also used as an index into stateSeg[] in Display_Update. */
typedef enum { ST_GREEN, ST_YELLOW, ST_RED } TrafficState;

/* Variables shared between ISRs and the main loop MUST be "volatile".
 * volatile tells the compiler that the value may change at any time outside
 * the normal program flow (inside an interrupt), so it must re-read the
 * variable from RAM every time instead of keeping a stale copy in a CPU
 * register. Without volatile, the main loop might never see a flag change.  */
static volatile uint8_t  pedRequest   = 0;  /* 1 = S1 pressed, pedestrian waiting
                                               (set by PORTB ISR, cleared when
                                               the request is served)          */
static volatile uint8_t  emergencyReq = 0;  /* 1 = S2 pressed (set by PORTB ISR,
                                               cleared by main loop)           */
static volatile uint8_t  secondFlag   = 0;  /* 1 = one second has passed
                                               (set by PIT0 ISR, cleared by
                                               main loop)                      */
static volatile uint32_t tick2ms      = 0;  /* free-running counter, +1 every
                                               2 ms in PIT1 ISR. Used as a
                                               time stamp for debouncing.      */
static volatile uint16_t buzzerTicks  = 0;  /* remaining buzzer ON time in 2 ms
                                               ticks. PIT1 ISR counts it down
                                               and turns the buzzer off at 0.  */
static volatile uint8_t  disp[4] = {        /* display buffer: segment byte for
                                               each of the 4 digits (left to
                                               right). Main loop writes it,
                                               PIT1 ISR reads it.              */
    SEG_BLANK, SEG_BLANK, SEG_BLANK, SEG_BLANK
};

/* Variables used only by the main loop (no ISR access -> no volatile needed) */
static TrafficState state;         /* current car light state                  */
static uint8_t remaining;          /* seconds left in the current state        */
static uint8_t pedWalking    = 0;  /* 1 = pedestrians are crossing right now   */
static uint8_t emergencyMode = 0;  /* 1 = police-control mode is active        */

/* ============================================================================
 *  LED DRIVER
 *  Hardware: each LED anode -> resistor -> +5 V, cathode -> MCU pin.
 *  Pin LOW  -> current flows -> LED ON
 *  Pin HIGH -> no current   -> LED OFF      (active LOW)
 * ==========================================================================*/

/* Configure PTD0..PTD3 as GPIO outputs and switch all four LEDs off. */
static void LED_Init(void) {
    /* 1) Enable the clock gate of Port D in SIM_SCGC5.
     *    Every peripheral on the K64F is unclocked after reset to save power;
     *    accessing its registers without the clock causes a hard fault.     */
    SIM->SCGC5 |= SIM_SCGC5_PORTD_MASK;

    /* 2) Pin Control Register (PCR): MUX field selects the pin function.
     *    MUX = 1 (ALT1) = GPIO on every K64F pin.                           */
    PORTD->PCR[LED_RED]    = PORT_PCR_MUX(1);
    PORTD->PCR[LED_YELLOW] = PORT_PCR_MUX(1);
    PORTD->PCR[LED_GREEN]  = PORT_PCR_MUX(1);
    PORTD->PCR[LED_WALK]   = PORT_PCR_MUX(1);

    /* 3) Drive all four pins HIGH first (= LEDs OFF) using the Port Set
     *    Output Register. PSOR only affects bits written as 1, so other
     *    pins of Port D are not touched. Doing this BEFORE switching the
     *    pins to outputs prevents a short flash of the LEDs at start-up.    */
    PTD->PSOR  = MASK(LED_RED) | MASK(LED_YELLOW) | MASK(LED_GREEN) | MASK(LED_WALK);

    /* 4) Port Data Direction Register: bit = 1 -> output.
     *    "|=" sets only our 4 bits and keeps the direction of other pins.   */
    PTD->PDDR |= MASK(LED_RED) | MASK(LED_YELLOW) | MASK(LED_GREEN) | MASK(LED_WALK);
}

/* Turn one LED on (on != 0) or off (on == 0).
 * PCOR (Port Clear Output Register) drives the pin LOW  -> LED ON.
 * PSOR (Port Set Output Register)   drives the pin HIGH -> LED OFF.
 * Both are atomic: one write changes only the selected pin, no
 * read-modify-write of the whole port is needed.                            */
static void LED_Set(uint8_t pin, uint8_t on) {
    if (on) PTD->PCOR = MASK(pin);
    else    PTD->PSOR = MASK(pin);
}

/* Invert the current state of one LED.
 * PTOR (Port Toggle Output Register): writing 1 flips that output bit.      */
static void LED_Toggle(uint8_t pin) {
    PTD->PTOR = MASK(pin);
}

/* ============================================================================
 *  SWITCH S1, S2 + PORT INTERRUPT
 *  Hardware: each button connects the pin to GND when pressed. A 10k pull-up
 *  on the shield (plus the internal pull-up enabled below) keeps the pin
 *  HIGH when released.
 *      released -> pin = 1 (HIGH)
 *      pressed  -> pin = 0 (LOW)
 *  So a press produces a FALLING EDGE (1 -> 0), which triggers the interrupt.
 * ==========================================================================*/
static void Switch_Init(void) {
    /* Clock gate for Port B (S1 = PTB3, S2 = PTB10). */
    SIM->SCGC5 |= SIM_SCGC5_PORTB_MASK;

    /* PCR settings for each button pin:
     *   MUX(1)     -> GPIO function
     *   PE = 1     -> Pull Enable: turn on the internal pull resistor
     *   PS = 1     -> Pull Select: 1 = pull-UP (0 would be pull-down)
     *   IRQC(0xA)  -> Interrupt Configuration = 1010b
     *                 = interrupt on FALLING edge
     *                 (1001b = rising edge, 1011b = either edge,
     *                  1000b = logic 0 level, 0000b = disabled)            */
    PORTB->PCR[SW1] = PORT_PCR_MUX(1) | PORT_PCR_PE_MASK | PORT_PCR_PS_MASK
                    | PORT_PCR_IRQC(0xA);
    PORTB->PCR[SW2] = PORT_PCR_MUX(1) | PORT_PCR_PE_MASK | PORT_PCR_PS_MASK
                    | PORT_PCR_IRQC(0xA);

    /* Clear bits 3 and 10 in PDDR -> both pins are inputs.
     * "&= ~(...)" clears only these bits and leaves the others unchanged
     * (important because PTB23 is used as an output for the 7-segment).    */
    PTB->PDDR &= ~(MASK(SW1) | MASK(SW2));

    /* Interrupt Status Flag Register: a flag may already be set from
     * power-up noise. ISFR is "write 1 to clear" (w1c), so writing 1 to
     * bit 3 and bit 10 clears those flags.                                  */
    PORTB->ISFR = MASK(SW1) | MASK(SW2);

    /* NVIC = Nested Vectored Interrupt Controller (in the Cortex-M4 core).
     * Clear any pending PORTB request, then enable the PORTB interrupt line
     * so that PORTB_IRQHandler() is called when a flag is set.              */
    NVIC_ClearPendingIRQ(PORTB_IRQn);
    NVIC_EnableIRQ(PORTB_IRQn);
}

/* PORTB interrupt service routine.
 * The name must match the vector table entry in the startup file exactly.
 * ALL pins of Port B share this one handler, so the ISR checks ISFR to find
 * which pin caused the interrupt.                                           */
void PORTB_IRQHandler(void) {
    /* "static" local variables keep their value between calls.
     * They store the time (in 2 ms ticks) of the last accepted press.       */
    static uint32_t lastS1 = 0, lastS2 = 0;

    /* ---- S1 : pedestrian button ---- */
    if (PORTB->ISFR & MASK(SW1)) {
        /* Software debounce: a mechanical button "bounces" and produces
         * several edges within a few ms. Only accept the press if more than
         * DEBOUNCE_TICKS (200 ms) have passed since the last accepted one.
         * Unsigned subtraction still works correctly when tick2ms
         * overflows from 0xFFFFFFFF back to 0.                              */
        if ((tick2ms - lastS1) > DEBOUNCE_TICKS) {
            pedRequest = 1;        /* only set a flag; main loop does the work */
            lastS1 = tick2ms;
        }
        /* Clear the flag (write 1). If it is not cleared, the interrupt
         * stays pending and the CPU re-enters this ISR forever.             */
        PORTB->ISFR = MASK(SW1);
    }

    /* ---- S2 : police emergency button ---- */
    if (PORTB->ISFR & MASK(SW2)) {
        if ((tick2ms - lastS2) > DEBOUNCE_TICKS) {
            emergencyReq = 1;      /* main loop will toggle emergency mode     */
            lastS2 = tick2ms;
        }
        PORTB->ISFR = MASK(SW2);   /* w1c: clear S2 flag                       */
    }
}

/* ============================================================================
 *  BUZZER DRIVER (volume control with FTM0 PWM)
 *
 *  PTA1 can be routed to FlexTimer 0 channel 6 (FTM0_CH6, pin mux ALT3), so
 *  the hardware timer generates the PWM signal by itself - no CPU time is
 *  used while the buzzer sounds.
 *
 *  Q1 is a PNP transistor -> buzzer is ON while the pin is LOW. Therefore a
 *  "low-true" PWM is used: in each period the pin is LOW for CnV counts and
 *  HIGH for the rest.
 *
 *        |<-------- one period = MOD+1 counts (250 us at 4 kHz) -------->|
 *   pin  ____________                       ____________
 *            LOW     |_____ HIGH __________|    LOW     |_____ ...
 *        |<- CnV ->|
 *
 *  duty cycle  = CnV / (MOD + 1)  = fraction of time the buzzer is driven
 *  loudness   ~= duty cycle   (smaller duty -> less average power -> quieter)
 *  CnV = 0  -> pin never LOW  -> buzzer completely OFF
 * ==========================================================================*/
static uint8_t buzzVolume = BUZZ_VOLUME;   /* current loudness 0-100 %         */

/* Return the bus clock frequency in Hz.
 * PIT and FTM are both clocked from the bus clock.
 *   SystemCoreClockUpdate() recalculates SystemCoreClock (core clock in Hz)
 *   from the current clock registers.
 *   SIM_CLKDIV1.OUTDIV2 is the bus clock divider: bus = core / (OUTDIV2 + 1).
 * Calculating it at run time makes the timing correct whatever clock setup
 * the startup code uses (e.g. 20.97 MHz default or 120 MHz).               */
static uint32_t Bus_GetClock(void) {
    SystemCoreClockUpdate();
    return SystemCoreClock /
           (((SIM->CLKDIV1 & SIM_CLKDIV1_OUTDIV2_MASK) >> SIM_CLKDIV1_OUTDIV2_SHIFT) + 1);
}

/* Configure PTA1 as FTM0_CH6 and set up a 4 kHz edge-aligned PWM, start OFF. */
static void Buzzer_Init(void) {
    SIM->SCGC5 |= SIM_SCGC5_PORTA_MASK;   /* clock gate for Port A           */
    SIM->SCGC6 |= SIM_SCGC6_FTM0_MASK;    /* clock gate for FlexTimer 0      */
    PORTA->PCR[BUZZER] = PORT_PCR_MUX(3); /* ALT3: PTA1 -> FTM0_CH6 output   */

    /* Some FTM registers are write-protected after reset.
     * WPDIS = 1 disables the write protection.                             */
    FTM0->MODE |= FTM_MODE_WPDIS_MASK;

    FTM0->SC    = 0;      /* Status & Control: CLKS = 0 -> counter stopped
                             while configuring; also clears TOIE, CPWMS
                             (CPWMS = 0 -> up-counting, edge-aligned mode)   */
    FTM0->CNTIN = 0;      /* counter initial value: counts from 0            */
    FTM0->CNT   = 0;      /* writing CNT loads it with CNTIN (reset counter) */

    /* MOD = terminal count. The counter counts 0 .. MOD, then restarts.
     * PWM period = (MOD + 1) / f_bus  ->  MOD = f_bus / f_pwm - 1
     * Example at 20.97 MHz bus: 20971520 / 4000 - 1 = 5241                 */
    FTM0->MOD   = (Bus_GetClock() / BUZZ_PWM_FREQ) - 1;

    /* Channel 6 Status & Control (CnSC):
     *   MSB = 1, MSA = 0   -> edge-aligned PWM mode
     *   ELSB = 0, ELSA = 1 -> "low-true pulses": output goes LOW when the
     *                         counter restarts and HIGH when CNT matches CnV
     *   (ELSB = 1, ELSA = 0 would give high-true pulses, which would turn
     *    the PNP-driven buzzer ON most of the time at small duty values)   */
    FTM0->CONTROLS[6].CnSC = FTM_CnSC_MSB_MASK | FTM_CnSC_ELSA_MASK;
    FTM0->CONTROLS[6].CnV  = 0;           /* duty 0 % = buzzer OFF           */

    /* Start the counter:
     *   CLKS = 1 -> clock source = system (bus) clock
     *   PS   = 0 -> prescaler divide by 1                                  */
    FTM0->SC = FTM_SC_CLKS(1) | FTM_SC_PS(0);
}

/* Set the loudness used by the next Buzzer_On() call (0-100 %).
 * Values above 100 are clipped to 100.                                      */
static void Buzzer_SetVolume(uint8_t percent) {
    if (percent > 100) percent = 100;
    buzzVolume = percent;
}

/* Start sound: write the duty cycle into CnV.
 * CnV = (MOD + 1) x volume / 100   (e.g. 5 % of 5242 counts = 262 counts).
 * The new CnV value takes effect from the next PWM period.                  */
static void Buzzer_On(void) {
    FTM0->CONTROLS[6].CnV = ((FTM0->MOD + 1) * buzzVolume) / 100;
}

/* Stop sound: duty 0 % -> pin stays HIGH -> PNP transistor off. */
static void Buzzer_Off(void) {
    FTM0->CONTROLS[6].CnV = 0;
}

/* Non-blocking beep: switch the buzzer on and store how long it should stay
 * on. The PIT1 ISR (every 2 ms) counts buzzerTicks down and calls
 * Buzzer_Off() when it reaches 0. The main loop never waits (no delay()),
 * so buttons and the display keep working during the beep.                 */
static void Buzzer_Beep(uint16_t ms) {
    buzzerTicks = ms / 2;     /* convert ms -> number of 2 ms ticks           */
    Buzzer_On();
}

/* ============================================================================
 *  7-SEGMENT DRIVER (2 x 74HC595 shift registers)
 *
 *  Data path (from the shield schematic):
 *    MCU SEG_DATA -> SDI of U2 -> SDO of U2 -> SDI of U3
 *    U3 outputs QA..QH -> segment lines a..g, dp (shared by all 4 digits)
 *    U2 outputs QA..QD -> common anodes of digit 1..4
 *
 *  To show one digit, 16 bits are shifted in: first the segment byte, then
 *  the digit-select byte. After 16 clocks the first byte has been pushed
 *  through U2 into U3 (segments) and the second byte stays in U2 (digit).
 *
 *  74HC595 signals:
 *    SFTCLK (shift clock)  : on each RISING edge the bit on SDI is shifted in
 *    LCHCLK (latch clock)  : on a RISING edge the shift register content is
 *                            copied to the output pins all at once, so the
 *                            display never shows half-shifted garbage.
 * ==========================================================================*/

/* Configure the three control pins as GPIO outputs. */
static void SevenSeg_Init(void) {
    /* LATCH is on Port B, CLK and DATA are on Port C. */
    SIM->SCGC5 |= SIM_SCGC5_PORTB_MASK | SIM_SCGC5_PORTC_MASK;
    PORTB->PCR[SEG_LATCH] = PORT_PCR_MUX(1);   /* PTB23 -> GPIO */
    PORTC->PCR[SEG_CLK]   = PORT_PCR_MUX(1);   /* PTC3  -> GPIO */
    PORTC->PCR[SEG_DATA]  = PORT_PCR_MUX(1);   /* PTC12 -> GPIO */
    PTB->PDDR |= MASK(SEG_LATCH);                /* outputs        */
    PTC->PDDR |= MASK(SEG_CLK) | MASK(SEG_DATA);
    PTC->PCOR  = MASK(SEG_CLK);                  /* clock idles LOW */
}

/* Send one byte to the shift registers, most significant bit first
 * (software "bit-banging", same as Arduino shiftOut(..., MSBFIRST, ...)).   */
static void SevenSeg_ShiftOut(uint8_t value) {
    for (int i = 7; i >= 0; i--) {                 /* bit 7 down to bit 0     */
        /* 1) put the current bit on the DATA line */
        if (value & (1u << i)) PTC->PSOR = MASK(SEG_DATA);   /* bit = 1 -> HIGH */
        else                   PTC->PCOR = MASK(SEG_DATA);   /* bit = 0 -> LOW  */
        /* 2) pulse the shift clock: the 74HC595 samples DATA on the
         *    rising edge, then the clock returns LOW for the next bit       */
        PTC->PSOR = MASK(SEG_CLK);
        PTC->PCOR = MASK(SEG_CLK);
    }
}

/* Show segment pattern "seg" on digit number "pos" (0 = leftmost). */
static void SevenSeg_WriteDigit(uint8_t pos, uint8_t seg) {
    PTB->PCOR = MASK(SEG_LATCH);         /* latch LOW: outputs hold old value */
    SevenSeg_ShiftOut(seg);              /* 1st byte -> ends up in U3 (segments) */
    SevenSeg_ShiftOut(DIGIT_SEL[pos]);   /* 2nd byte -> stays in U2 (digit select) */
    PTB->PSOR = MASK(SEG_LATCH);         /* rising edge: new 16 bits appear on
                                            the outputs at the same instant    */
}

/* Display multiplexing - called every 2 ms from the PIT1 ISR.
 * The four digits share the same segment lines, so only ONE digit can be
 * lit at a time. Each call lights the next digit:
 *   digit 0 -> 1 -> 2 -> 3 -> 0 ...  (each for 2 ms)
 * Full cycle = 4 x 2 ms = 8 ms -> 125 refreshes per second. This is faster
 * than the eye can follow (persistence of vision), so all four digits
 * appear to be on continuously without flicker.                             */
static void SevenSeg_Refresh(void) {
    static uint8_t pos = 0;              /* digit to show this time (kept
                                            between calls)                    */
    SevenSeg_WriteDigit(pos, disp[pos]);
    pos = (pos + 1) & 0x03;              /* next digit; "& 0x03" wraps 3 -> 0 */
}

/* Copy four segment patterns into the display buffer.
 * The buffer is shown by SevenSeg_Refresh() in the background, so the
 * caller does not have to refresh the display itself.                       */
static void SevenSeg_Show(uint8_t d0, uint8_t d1, uint8_t d2, uint8_t d3) {
    disp[0] = d0; disp[1] = d1; disp[2] = d2; disp[3] = d3;
}

/* ============================================================================
 *  TIMER : PIT (Periodic Interrupt Timer)
 *
 *  Each PIT channel is a 32-bit DOWN counter clocked by the bus clock:
 *    - it loads LDVAL, counts down to 0,
 *    - at 0 it sets the TIF flag (and requests an interrupt if TIE = 1),
 *    - then automatically reloads LDVAL and starts again.
 *  Period = (LDVAL + 1) / f_bus   ->   LDVAL = f_bus x period - 1
 * ==========================================================================*/
static void PIT_Init(void) {
    uint32_t busClk = Bus_GetClock();     /* bus clock in Hz                  */

    SIM->SCGC6 |= SIM_SCGC6_PIT_MASK;     /* clock gate for the PIT module    */

    /* Module Control Register:
     *   MDIS = 0 -> module enabled (it is disabled after reset)
     *   FRZ  = 0 -> timers keep running while the debugger halts the CPU   */
    PIT->MCR = 0;

    /* ---- Channel 0 : 1 second ----
     * LDVAL = f_bus x 1 s - 1  (e.g. 20 971 520 - 1 at 20.97 MHz)          */
    PIT->CHANNEL[0].LDVAL = busClk - 1;
    PIT->CHANNEL[0].TFLG  = PIT_TFLG_TIF_MASK;   /* clear old flag (w1c)       */
    PIT->CHANNEL[0].TCTRL = PIT_TCTRL_TIE_MASK   /* TIE: interrupt enable      */
                          | PIT_TCTRL_TEN_MASK;  /* TEN: start the timer       */

    /* ---- Channel 1 : 2 ms ----
     * 2 ms = 1/500 s -> LDVAL = f_bus / 500 - 1                             */
    PIT->CHANNEL[1].LDVAL = (busClk / 500) - 1;
    PIT->CHANNEL[1].TFLG  = PIT_TFLG_TIF_MASK;
    PIT->CHANNEL[1].TCTRL = PIT_TCTRL_TIE_MASK | PIT_TCTRL_TEN_MASK;

    /* Each PIT channel has its own interrupt line in the NVIC. */
    NVIC_EnableIRQ(PIT0_IRQn);
    NVIC_EnableIRQ(PIT1_IRQn);
}

/* PIT channel 0 ISR - runs once per second.
 * It only signals the main loop; the traffic logic itself runs in main().   */
void PIT0_IRQHandler(void) {
    PIT->CHANNEL[0].TFLG = PIT_TFLG_TIF_MASK;   /* clear TIF (write 1), else the
                                                   ISR would be re-entered     */
    secondFlag = 1;                             /* "1 second passed" event     */
}

/* PIT channel 1 ISR - runs every 2 ms. Handles all fast, periodic jobs:
 *   1) time stamp counter for debounce
 *   2) 7-segment multiplexing (one digit per call)
 *   3) ending a buzzer beep at the right moment                            */
void PIT1_IRQHandler(void) {
    PIT->CHANNEL[1].TFLG = PIT_TFLG_TIF_MASK;   /* clear TIF                   */
    tick2ms++;                                  /* system time in 2 ms units   */
    SevenSeg_Refresh();                         /* show next digit             */
    if (buzzerTicks) {                          /* a beep is in progress?      */
        if (--buzzerTicks == 0) Buzzer_Off();   /* time is up -> stop sound    */
    }
}

/* ============================================================================
 *  TRAFFIC LIGHT : COMMON HELPER
 * ==========================================================================*/

/* Enter a new car-light state:
 *   - switch the car LEDs so that exactly one of R / Y / G is on,
 *   - load the duration of the new state into "remaining",
 *   - when entering RED, start the pedestrian phase if someone is waiting,
 *   - update the WALK LED.                                                  */
static void Traffic_SetState(TrafficState s) {
    state = s;

    /* (s == ST_GREEN) evaluates to 1 or 0 -> LED on or off. */
    LED_Set(LED_GREEN,  s == ST_GREEN);
    LED_Set(LED_YELLOW, s == ST_YELLOW);
    LED_Set(LED_RED,    s == ST_RED);

    switch (s) {
    case ST_GREEN:  remaining = T_GREEN;  break;
    case ST_YELLOW: remaining = T_YELLOW; break;
    case ST_RED:
        remaining = T_RED;
        if (pedRequest) {          /* a pedestrian pressed S1 earlier:        */
            pedRequest = 0;        /*   request is now being served           */
            pedWalking = 1;        /*   allow crossing during this red phase  */
        }
        break;
    }
    LED_Set(LED_WALK, pedWalking); /* WALK light follows pedWalking            */
}

/* ============================================================================
 *  FUNCTION 1 : NORMAL TRAFFIC LIGHT  (called once per second)
 *
 *  State machine:
 *      +-------+  T_GREEN s  +--------+  T_YELLOW s  +-----+
 *      | GREEN | ----------> | YELLOW | -----------> | RED |
 *      +-------+             +--------+              +-----+
 *          ^                                            |
 *          +------------------- T_RED s ----------------+
 * ==========================================================================*/
static void Traffic_Normal(void) {
    if (remaining > 0) remaining--;        /* count down one second           */

    if (remaining == 0) {                  /* time of this state is over      */
        switch (state) {
        case ST_GREEN:  Traffic_SetState(ST_YELLOW); break;
        case ST_YELLOW: Traffic_SetState(ST_RED);    break;
        case ST_RED:
            pedWalking = 0;                /* crossing time is over: WALK off */
            Traffic_SetState(ST_GREEN);
            break;
        }
    }
}

/* ============================================================================
 *  FUNCTION 2 : PEDESTRIAN CROSSING  (called once per second, after
 *               Traffic_Normal)
 *
 *  pedRequest is set by the S1 interrupt. This function decides what to do
 *  with the request depending on the current car-light state:
 *    GREEN  -> shorten green, crossing starts on the following red
 *    YELLOW -> nothing to do now, Traffic_SetState(ST_RED) serves it
 *    RED    -> cars already stopped, start crossing immediately
 *  While crossing, the buzzer gives one short beep per second.
 * ==========================================================================*/
static void Traffic_Pedestrian(void) {
    /* Case GREEN: cut the remaining green time so the pedestrian does not
     * wait too long. Only shorten, never lengthen (if fewer than
     * T_PED_SHORTEN seconds are left, keep the current value).              */
    if (pedRequest && state == ST_GREEN && remaining > T_PED_SHORTEN) {
        remaining = T_PED_SHORTEN;
    }

    /* Case RED: cars are already stopped -> walk right now.
     * "!pedWalking" makes sure this is only done once.                      */
    if (pedRequest && state == ST_RED && !pedWalking) {
        pedRequest = 0;                    /* request served                  */
        pedWalking = 1;                    /* crossing phase starts           */
        LED_Set(LED_WALK, 1);              /* WALK light ON                   */
        if (remaining < T_WALK_MIN) {
            remaining = T_WALK_MIN;        /* extend red so there is enough
                                              time to cross safely            */
        }
    }

    /* Audible crossing signal: short beep every second while crossing. */
    if (pedWalking) {
        Buzzer_Beep(BEEP_WALK);
    }
}

/* ============================================================================
 *  FUNCTION 3 : POLICE EMERGENCY
 *    Emergency_Toggle()  : called once each time S2 is pressed (enter / exit)
 *    Traffic_Emergency() : called once per second while in emergency mode
 * ==========================================================================*/

/* Switch between normal mode and police-control mode. */
static void Emergency_Toggle(void) {
    if (!emergencyMode) {
        /* ---------------- ENTER police-control mode ---------------- */
        emergencyMode = 1;
        pedWalking = 0;                    /* cancel any running crossing
                                              (a waiting pedRequest is kept
                                              and served after the emergency) */
        LED_Set(LED_GREEN,  0);
        LED_Set(LED_YELLOW, 0);            /* will blink in Traffic_Emergency */
        LED_Set(LED_WALK,   0);
        LED_Set(LED_RED,    1);            /* RED: all cars must stop         */
        Buzzer_SetVolume(BUZZ_VOL_EMG);    /* use emergency loudness          */
        Buzzer_Beep(BEEP_EMG_ENTER);       /* longer beep = police in control */
    } else {
        /* ---------------- EXIT police-control mode ----------------- */
        emergencyMode = 0;
        Buzzer_SetVolume(BUZZ_VOLUME);     /* back to normal loudness         */
        Buzzer_Beep(BEEP_EMG_EXIT);        /* short confirmation beep         */
        Traffic_SetState(ST_RED);          /* restart the cycle from RED so
                                              cars never get green suddenly;
                                              a waiting pedestrian crosses now */
    }
}

/* Runs every second during police control: blink yellow + tick sound.
 * Traffic_Normal() is NOT called in this mode, so the light stays red and
 * the countdown is frozen until S2 is pressed again.                        */
static void Traffic_Emergency(void) {
    LED_Toggle(LED_YELLOW);                /* yellow ON 1 s / OFF 1 s = warning */
    Buzzer_Beep(BEEP_EMG_TICK);            /* short tick every second         */
}

/* ============================================================================
 *  DISPLAY CONTENT
 *  Decides WHAT the 4 digits should show and writes it to the buffer.
 *  (HOW it is shown is done by SevenSeg_Refresh() in the PIT1 ISR.)
 *
 *  Normal mode :  [state] [P or blank] [tens of remaining] [ones of remaining]
 *                 e.g. "G  12", "Y   3", "rP  8"
 *  Emergency   :  "StoP"
 * ==========================================================================*/
static void Display_Update(void) {
    /* Lookup table indexed by TrafficState: ST_GREEN=0, ST_YELLOW=1, ST_RED=2 */
    static const uint8_t stateSeg[3] = { SEG_G, SEG_Y, SEG_r };

    if (emergencyMode) {
        SevenSeg_Show(SEG_S, SEG_t, SEG_o, SEG_P);         /* "StoP" */
    } else {
        SevenSeg_Show(
            stateSeg[state],                                    /* digit 1: G / Y / r            */
            (pedRequest || pedWalking) ? SEG_P : SEG_BLANK,     /* digit 2: 'P' if pedestrian
                                                                   is waiting or crossing         */
            (remaining >= 10) ? SEG_NUM[remaining / 10]         /* digit 3: tens, blank if < 10  */
                              : SEG_BLANK,
            SEG_NUM[remaining % 10]);                           /* digit 4: ones                 */
    }
}

/* ============================================================================
 *  MAIN
 *  Only initialisation and calls to the function blocks (as required by the
 *  project rules - no device logic is written directly in main).
 * ==========================================================================*/
int main(void) {
    /* ---- Initialisation ----
     * The PIT is started LAST, so its interrupts cannot run before the LEDs,
     * buzzer, display and initial state are ready.                          */
    LED_Init();                 /* car + walk LEDs                            */
    Buzzer_Init();              /* FTM0 PWM for buzzer                        */
    SevenSeg_Init();            /* 74HC595 control pins                       */
    Switch_Init();              /* S1, S2 + PORTB interrupt                   */
    Traffic_SetState(ST_RED);   /* safe power-up state: cars stopped          */
    PIT_Init();                 /* start 1 s and 2 ms time bases              */

    /* ---- Super loop (runs forever) ---- */
    while (1) {
        /* Event 1: S2 was pressed (flag from PORTB ISR) */
        if (emergencyReq) {
            emergencyReq = 0;              /* consume the event               */
            Emergency_Toggle();            /* Function 3: enter / exit        */
        }

        /* Event 2: one second has passed (flag from PIT0 ISR) */
        if (secondFlag) {
            secondFlag = 0;                /* consume the event               */
            if (emergencyMode) {
                Traffic_Emergency();       /* Function 3: blink + tick        */
            } else {
                Traffic_Normal();          /* Function 1: count down / change light */
                Traffic_Pedestrian();      /* Function 2: handle S1 request   */
            }
        }

        /* Always keep the display buffer up to date (cheap, no waiting). */
        Display_Update();
    }
}
